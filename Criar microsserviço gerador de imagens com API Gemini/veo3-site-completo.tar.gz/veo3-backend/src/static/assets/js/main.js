// ===== MAIN JAVASCRIPT =====

// Global state management
const AppState = {
    currentTheme: 'dark',
    isNavOpen: false,
    currentUser: null,
    generationHistory: [],
    galleryItems: [],
    promptTemplates: []
};

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    initializeNavigation();
    initializeThemeSystem();
    initializeLucideIcons();
    initializeAnimations();
    loadGalleryItems();
    loadPromptTemplates();
});

function initializeApp() {
    console.log('🚀 VEO3 Photo Generator - Inicializando...');
    
    // Load saved theme
    const savedTheme = localStorage.getItem('veo3-theme') || 'dark';
    setTheme(savedTheme);
    
    // Load user preferences
    loadUserPreferences();
    
    // Initialize tooltips and interactive elements
    initializeTooltips();
    
    console.log('✅ Aplicação inicializada com sucesso');
}

// ===== NAVIGATION =====
function initializeNavigation() {
    const navToggle = document.getElementById('navToggle');
    const navMenu = document.getElementById('navMenu');
    const navLinks = document.querySelectorAll('.nav-link');
    
    // Mobile menu toggle
    if (navToggle) {
        navToggle.addEventListener('click', toggleMobileMenu);
    }
    
    // Smooth scrolling for navigation links
    navLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href.startsWith('#')) {
                e.preventDefault();
                smoothScrollTo(href);
                setActiveNavLink(this);
                
                // Close mobile menu if open
                if (AppState.isNavOpen) {
                    toggleMobileMenu();
                }
            }
        });
    });
    
    // Update active nav link on scroll
    window.addEventListener('scroll', updateActiveNavOnScroll);
    
    // Navbar background on scroll
    window.addEventListener('scroll', updateNavbarBackground);
}

function toggleMobileMenu() {
    const navMenu = document.getElementById('navMenu');
    const navToggle = document.getElementById('navToggle');
    
    AppState.isNavOpen = !AppState.isNavOpen;
    
    if (AppState.isNavOpen) {
        navMenu.style.display = 'flex';
        navMenu.style.position = 'absolute';
        navMenu.style.top = '100%';
        navMenu.style.left = '0';
        navMenu.style.right = '0';
        navMenu.style.background = 'var(--bg-secondary)';
        navMenu.style.border = '1px solid var(--border-primary)';
        navMenu.style.borderRadius = 'var(--radius-lg)';
        navMenu.style.padding = 'var(--space-lg)';
        navMenu.style.flexDirection = 'column';
        navMenu.style.gap = 'var(--space-md)';
        navMenu.style.zIndex = '1000';
        
        navToggle.innerHTML = '<i data-lucide="x"></i>';
    } else {
        navMenu.style.display = '';
        navMenu.style.position = '';
        navMenu.style.top = '';
        navMenu.style.left = '';
        navMenu.style.right = '';
        navMenu.style.background = '';
        navMenu.style.border = '';
        navMenu.style.borderRadius = '';
        navMenu.style.padding = '';
        navMenu.style.flexDirection = '';
        navMenu.style.gap = '';
        navMenu.style.zIndex = '';
        
        navToggle.innerHTML = '<i data-lucide="menu"></i>';
    }
    
    // Re-initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function smoothScrollTo(target) {
    const element = document.querySelector(target);
    if (element) {
        const offsetTop = element.offsetTop - 80; // Account for fixed navbar
        window.scrollTo({
            top: offsetTop,
            behavior: 'smooth'
        });
    }
}

function setActiveNavLink(activeLink) {
    document.querySelectorAll('.nav-link').forEach(link => {
        link.classList.remove('active');
    });
    activeLink.classList.add('active');
}

function updateActiveNavOnScroll() {
    const sections = document.querySelectorAll('section[id]');
    const scrollPos = window.scrollY + 100;
    
    sections.forEach(section => {
        const top = section.offsetTop;
        const bottom = top + section.offsetHeight;
        const id = section.getAttribute('id');
        
        if (scrollPos >= top && scrollPos <= bottom) {
            const navLink = document.querySelector(`.nav-link[href="#${id}"]`);
            if (navLink) {
                setActiveNavLink(navLink);
            }
        }
    });
}

function updateNavbarBackground() {
    const navbar = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        navbar.style.background = 'rgba(15, 15, 15, 0.95)';
        navbar.style.backdropFilter = 'blur(20px)';
    } else {
        navbar.style.background = 'rgba(15, 15, 15, 0.8)';
        navbar.style.backdropFilter = 'blur(20px)';
    }
}

// ===== THEME SYSTEM =====
function initializeThemeSystem() {
    const themeToggle = document.getElementById('themeToggle');
    
    if (themeToggle) {
        themeToggle.addEventListener('click', toggleTheme);
    }
    
    // Initialize theme customization
    initializeThemeCustomization();
}

function toggleTheme() {
    const currentTheme = AppState.currentTheme;
    const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
    setTheme(newTheme);
}

function setTheme(themeName) {
    const body = document.body;
    const themeToggle = document.getElementById('themeToggle');
    
    // Remove all theme classes
    body.classList.remove('theme-dark', 'theme-light', 'theme-corporate', 'theme-creative', 'theme-minimal', 'theme-ocean', 'theme-sunset', 'theme-forest');
    
    // Add new theme class
    body.classList.add(`theme-${themeName}`);
    
    // Update state
    AppState.currentTheme = themeName;
    
    // Save to localStorage
    localStorage.setItem('veo3-theme', themeName);
    
    // Update theme toggle icon
    if (themeToggle) {
        const icon = themeToggle.querySelector('i');
        if (icon) {
            icon.setAttribute('data-lucide', themeName === 'dark' ? 'sun' : 'moon');
        }
    }
    
    // Re-initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Add theme change animation
    body.classList.add('theme-changing');
    setTimeout(() => {
        body.classList.remove('theme-changing');
    }, 500);
    
    console.log(`🎨 Tema alterado para: ${themeName}`);
}

function initializeThemeCustomization() {
    // Theme option buttons
    const themeOptions = document.querySelectorAll('.theme-option');
    themeOptions.forEach(option => {
        option.addEventListener('click', function() {
            const theme = this.getAttribute('data-theme');
            if (theme) {
                setTheme(theme);
                
                // Update active state
                themeOptions.forEach(opt => opt.classList.remove('active'));
                this.classList.add('active');
            }
        });
    });
    
    // Color pickers
    const primaryColorPicker = document.getElementById('primaryColor');
    const secondaryColorPicker = document.getElementById('secondaryColor');
    
    if (primaryColorPicker) {
        primaryColorPicker.addEventListener('change', function() {
            document.documentElement.style.setProperty('--primary', this.value);
            document.documentElement.style.setProperty('--primary-hover', adjustBrightness(this.value, -20));
        });
    }
    
    if (secondaryColorPicker) {
        secondaryColorPicker.addEventListener('change', function() {
            document.documentElement.style.setProperty('--secondary', this.value);
            document.documentElement.style.setProperty('--secondary-hover', adjustBrightness(this.value, -20));
        });
    }
}

function adjustBrightness(hex, percent) {
    // Convert hex to RGB
    const num = parseInt(hex.replace("#", ""), 16);
    const amt = Math.round(2.55 * percent);
    const R = (num >> 16) + amt;
    const G = (num >> 8 & 0x00FF) + amt;
    const B = (num & 0x0000FF) + amt;
    
    return "#" + (0x1000000 + (R < 255 ? R < 1 ? 0 : R : 255) * 0x10000 +
        (G < 255 ? G < 1 ? 0 : G : 255) * 0x100 +
        (B < 255 ? B < 1 ? 0 : B : 255)).toString(16).slice(1);
}

// ===== ANIMATIONS =====
function initializeAnimations() {
    // Typing animation for hero
    startTypingAnimation();
    
    // Progress bar animation
    startProgressAnimation();
    
    // Intersection Observer for scroll animations
    initializeScrollAnimations();
}

function startTypingAnimation() {
    const typingElement = document.getElementById('typingText');
    if (!typingElement) return;
    
    const texts = [
        'Uma executiva confiante em um escritório moderno, luz natural, fotografia profissional',
        'Produto elegante em fundo minimalista, fotografia comercial de alta qualidade',
        'Equipe diversa colaborando em ambiente criativo, iluminação dinâmica e moderna',
        'Paisagem urbana futurista ao entardecer, arquitetura contemporânea, cores vibrantes'
    ];
    
    let currentTextIndex = 0;
    let currentCharIndex = 0;
    let isDeleting = false;
    
    function typeText() {
        const currentText = texts[currentTextIndex];
        
        if (isDeleting) {
            typingElement.textContent = currentText.substring(0, currentCharIndex - 1);
            currentCharIndex--;
        } else {
            typingElement.textContent = currentText.substring(0, currentCharIndex + 1);
            currentCharIndex++;
        }
        
        let typeSpeed = isDeleting ? 50 : 100;
        
        if (!isDeleting && currentCharIndex === currentText.length) {
            typeSpeed = 2000; // Pause at end
            isDeleting = true;
        } else if (isDeleting && currentCharIndex === 0) {
            isDeleting = false;
            currentTextIndex = (currentTextIndex + 1) % texts.length;
            typeSpeed = 500; // Pause before next text
        }
        
        setTimeout(typeText, typeSpeed);
    }
    
    typeText();
}

function startProgressAnimation() {
    const progressFill = document.getElementById('progressFill');
    if (!progressFill) return;
    
    let progress = 0;
    const interval = setInterval(() => {
        progress += Math.random() * 15;
        if (progress >= 100) {
            progress = 100;
            setTimeout(() => {
                progress = 0;
                progressFill.style.width = '0%';
            }, 1000);
        }
        progressFill.style.width = progress + '%';
        
        if (progress >= 100) {
            setTimeout(() => {
                progress = 0;
            }, 2000);
        }
    }, 300);
}

function initializeScrollAnimations() {
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.opacity = '1';
                entry.target.style.transform = 'translateY(0)';
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    const animatedElements = document.querySelectorAll('.feature-card, .gallery-item, .pricing-card');
    animatedElements.forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
}

// ===== UTILITY FUNCTIONS =====
function initializeLucideIcons() {
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

function initializeTooltips() {
    const tooltipElements = document.querySelectorAll('[title]');
    tooltipElements.forEach(element => {
        element.addEventListener('mouseenter', showTooltip);
        element.addEventListener('mouseleave', hideTooltip);
    });
}

function showTooltip(event) {
    const title = event.target.getAttribute('title');
    if (!title) return;
    
    // Create tooltip element
    const tooltip = document.createElement('div');
    tooltip.className = 'tooltip';
    tooltip.textContent = title;
    tooltip.style.cssText = `
        position: absolute;
        background: var(--bg-tertiary);
        color: var(--text-primary);
        padding: var(--space-sm) var(--space-md);
        border-radius: var(--radius-md);
        font-size: 0.75rem;
        z-index: var(--z-tooltip);
        pointer-events: none;
        border: 1px solid var(--border-primary);
        box-shadow: var(--shadow-lg);
    `;
    
    document.body.appendChild(tooltip);
    
    // Position tooltip
    const rect = event.target.getBoundingClientRect();
    tooltip.style.left = rect.left + (rect.width / 2) - (tooltip.offsetWidth / 2) + 'px';
    tooltip.style.top = rect.top - tooltip.offsetHeight - 8 + 'px';
    
    // Remove title to prevent default tooltip
    event.target.setAttribute('data-original-title', title);
    event.target.removeAttribute('title');
    
    // Store tooltip reference
    event.target._tooltip = tooltip;
}

function hideTooltip(event) {
    const tooltip = event.target._tooltip;
    if (tooltip) {
        tooltip.remove();
        delete event.target._tooltip;
    }
    
    // Restore title
    const originalTitle = event.target.getAttribute('data-original-title');
    if (originalTitle) {
        event.target.setAttribute('title', originalTitle);
        event.target.removeAttribute('data-original-title');
    }
}

function loadUserPreferences() {
    // Load saved preferences from localStorage
    const preferences = localStorage.getItem('veo3-preferences');
    if (preferences) {
        try {
            const parsed = JSON.parse(preferences);
            Object.assign(AppState, parsed);
        } catch (error) {
            console.warn('Erro ao carregar preferências:', error);
        }
    }
}

function saveUserPreferences() {
    // Save current preferences to localStorage
    const preferences = {
        currentTheme: AppState.currentTheme,
        generationHistory: AppState.generationHistory.slice(-50), // Keep last 50 items
        // Add other preferences as needed
    };
    
    localStorage.setItem('veo3-preferences', JSON.stringify(preferences));
}

// ===== HERO FUNCTIONS =====
function scrollToGenerator() {
    smoothScrollTo('#generator');
}

function openDemo() {
    // Open demo modal or redirect to demo page
    showNotification('Demo em breve! 🎬', 'info');
}

// ===== NOTIFICATION SYSTEM =====
function showNotification(message, type = 'info', duration = 3000) {
    const notification = document.createElement('div');
    notification.className = `notification notification-${type}`;
    notification.innerHTML = `
        <div class="notification-content">
            <span class="notification-message">${message}</span>
            <button class="notification-close" onclick="this.parentElement.parentElement.remove()">
                <i data-lucide="x"></i>
            </button>
        </div>
    `;
    
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--bg-secondary);
        border: 1px solid var(--border-primary);
        border-radius: var(--radius-lg);
        padding: var(--space-lg);
        z-index: var(--z-modal);
        min-width: 300px;
        box-shadow: var(--shadow-xl);
        transform: translateX(100%);
        transition: transform 0.3s ease;
    `;
    
    // Type-specific styling
    if (type === 'success') {
        notification.style.borderColor = 'var(--success)';
    } else if (type === 'error') {
        notification.style.borderColor = 'var(--error)';
    } else if (type === 'warning') {
        notification.style.borderColor = 'var(--warning)';
    }
    
    document.body.appendChild(notification);
    
    // Re-initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Animate in
    setTimeout(() => {
        notification.style.transform = 'translateX(0)';
    }, 100);
    
    // Auto remove
    if (duration > 0) {
        setTimeout(() => {
            notification.style.transform = 'translateX(100%)';
            setTimeout(() => {
                if (notification.parentElement) {
                    notification.remove();
                }
            }, 300);
        }, duration);
    }
}

// ===== MODAL FUNCTIONS =====
function openThemeModal() {
    const modal = document.getElementById('themeModal');
    if (modal) {
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
}

function closeThemeModal() {
    const modal = document.getElementById('themeModal');
    if (modal) {
        modal.classList.remove('active');
        document.body.style.overflow = '';
    }
}

function resetTheme() {
    setTheme('dark');
    
    // Reset custom colors
    document.documentElement.style.removeProperty('--primary');
    document.documentElement.style.removeProperty('--primary-hover');
    document.documentElement.style.removeProperty('--secondary');
    document.documentElement.style.removeProperty('--secondary-hover');
    
    showNotification('Tema resetado para o padrão', 'success');
}

function applyTheme() {
    saveUserPreferences();
    closeThemeModal();
    showNotification('Tema aplicado com sucesso!', 'success');
}

// ===== GALLERY FUNCTIONS =====
function loadGalleryItems() {
    // Mock gallery data - in real app, this would come from API
    const mockGalleryItems = [
        {
            id: 1,
            title: 'Executiva Confiante',
            prompt: 'Uma executiva confiante em um escritório moderno, luz natural, fotografia profissional',
            category: 'business',
            date: '2024-01-15',
            image: 'https://via.placeholder.com/400x300/2563EB/FFFFFF?text=Executiva'
        },
        {
            id: 2,
            title: 'Produto Elegante',
            prompt: 'Produto elegante em fundo minimalista, fotografia comercial',
            category: 'product',
            date: '2024-01-14',
            image: 'https://via.placeholder.com/400x300/7C3AED/FFFFFF?text=Produto'
        },
        {
            id: 3,
            title: 'Equipe Colaborativa',
            prompt: 'Equipe diversa colaborando em escritório moderno, ambiente dinâmico',
            category: 'people',
            date: '2024-01-13',
            image: 'https://via.placeholder.com/400x300/10B981/FFFFFF?text=Equipe'
        },
        {
            id: 4,
            title: 'Lifestyle Moderno',
            prompt: 'Pessoa jovem em ambiente urbano moderno, estilo de vida contemporâneo',
            category: 'lifestyle',
            date: '2024-01-12',
            image: 'https://via.placeholder.com/400x300/F59E0B/FFFFFF?text=Lifestyle'
        }
    ];
    
    AppState.galleryItems = mockGalleryItems;
    renderGalleryItems(mockGalleryItems);
}

function renderGalleryItems(items) {
    const galleryGrid = document.getElementById('galleryGrid');
    if (!galleryGrid) return;
    
    galleryGrid.innerHTML = items.map(item => `
        <div class="gallery-item" data-category="${item.category}" onclick="openGalleryModal(${item.id})">
            <img src="${item.image}" alt="${item.title}" class="gallery-image" loading="lazy">
            <div class="gallery-content">
                <h3 class="gallery-title">${item.title}</h3>
                <p class="gallery-prompt">${item.prompt}</p>
                <div class="gallery-meta">
                    <span class="gallery-category">${item.category}</span>
                    <span class="gallery-date">${formatDate(item.date)}</span>
                </div>
            </div>
        </div>
    `).join('');
}

function openGalleryModal(itemId) {
    const item = AppState.galleryItems.find(i => i.id === itemId);
    if (!item) return;
    
    showNotification(`Visualizando: ${item.title}`, 'info');
}

function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('pt-BR', { 
        day: '2-digit', 
        month: '2-digit' 
    });
}

// ===== PROMPT TEMPLATES =====
function loadPromptTemplates() {
    const templates = [
        {
            category: 'business',
            title: 'Executivo em Reunião',
            prompt: 'Executivo confiante em reunião de negócios, iluminação profissional'
        },
        {
            category: 'product',
            title: 'Produto Comercial',
            prompt: 'Produto elegante em fundo minimalista, fotografia comercial'
        },
        {
            category: 'people',
            title: 'Equipe Colaborativa',
            prompt: 'Equipe diversa colaborando em escritório moderno, ambiente dinâmico'
        }
    ];
    
    AppState.promptTemplates = templates;
}

function usePrompt(promptText) {
    const promptInput = document.getElementById('promptInput');
    if (promptInput) {
        promptInput.value = promptText;
        updatePromptCounter();
        showNotification('Prompt aplicado!', 'success', 2000);
    }
}

function updatePromptCounter() {
    const promptInput = document.getElementById('promptInput');
    const promptCounter = document.getElementById('promptCounter');
    
    if (promptInput && promptCounter) {
        const length = promptInput.value.length;
        promptCounter.textContent = length;
        
        // Update color based on length
        if (length > 450) {
            promptCounter.style.color = 'var(--error)';
        } else if (length > 350) {
            promptCounter.style.color = 'var(--warning)';
        } else {
            promptCounter.style.color = 'var(--text-muted)';
        }
    }
}

// ===== EVENT LISTENERS =====
// Add event listeners when DOM is ready
document.addEventListener('DOMContentLoaded', function() {
    // Prompt input counter
    const promptInput = document.getElementById('promptInput');
    if (promptInput) {
        promptInput.addEventListener('input', updatePromptCounter);
    }
    
    // Pricing toggle
    const pricingToggle = document.getElementById('pricingToggle');
    if (pricingToggle) {
        pricingToggle.addEventListener('click', togglePricing);
    }
    
    // Gallery filters
    const filterBtns = document.querySelectorAll('.filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', function() {
            const filter = this.getAttribute('data-filter');
            filterGallery(filter);
            
            // Update active state
            filterBtns.forEach(b => b.classList.remove('active'));
            this.classList.add('active');
        });
    });
    
    // Load more gallery items
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn) {
        loadMoreBtn.addEventListener('click', loadMoreGalleryItems);
    }
});

function togglePricing() {
    const toggle = document.getElementById('pricingToggle');
    const priceAmounts = document.querySelectorAll('.price-amount');
    
    toggle.classList.toggle('active');
    const isYearly = toggle.classList.contains('active');
    
    priceAmounts.forEach(amount => {
        const monthly = amount.getAttribute('data-monthly');
        const yearly = amount.getAttribute('data-yearly');
        amount.textContent = isYearly ? yearly : monthly;
    });
}

function filterGallery(category) {
    const items = category === 'all' ? AppState.galleryItems : 
                  AppState.galleryItems.filter(item => item.category === category);
    renderGalleryItems(items);
}

function loadMoreGalleryItems() {
    showNotification('Carregando mais itens...', 'info', 2000);
    // In real app, this would load more items from API
}

// ===== CLEANUP =====
window.addEventListener('beforeunload', function() {
    saveUserPreferences();
});

// ===== EXPORT FOR OTHER MODULES =====
window.VEO3 = {
    AppState,
    setTheme,
    showNotification,
    openThemeModal,
    closeThemeModal,
    usePrompt,
    smoothScrollTo
};

