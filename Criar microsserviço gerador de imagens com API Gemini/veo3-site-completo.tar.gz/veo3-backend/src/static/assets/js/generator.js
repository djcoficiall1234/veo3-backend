// ===== VEO3 PHOTO GENERATOR =====

// Generator state
const GeneratorState = {
    isGenerating: false,
    currentSettings: {
        style: 'professional',
        ratio: '1:1',
        quality: 4
    },
    generationQueue: [],
    lastGeneration: null
};

// ===== INITIALIZATION =====
document.addEventListener('DOMContentLoaded', function() {
    initializeGenerator();
});

function initializeGenerator() {
    console.log('🎨 Inicializando Gerador VEO3...');
    
    setupGeneratorControls();
    setupPromptHandling();
    setupGenerationActions();
    loadGeneratorPreferences();
    
    console.log('✅ Gerador VEO3 inicializado');
}

// ===== GENERATOR CONTROLS =====
function setupGeneratorControls() {
    // Style selector
    const styleSelect = document.getElementById('styleSelect');
    if (styleSelect) {
        styleSelect.addEventListener('change', function() {
            GeneratorState.currentSettings.style = this.value;
            updateStylePreview();
            saveGeneratorPreferences();
        });
    }
    
    // Ratio buttons
    const ratioButtons = document.querySelectorAll('.ratio-btn');
    ratioButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const ratio = this.getAttribute('data-ratio');
            selectRatio(ratio);
        });
    });
    
    // Quality slider
    const qualitySlider = document.getElementById('qualitySlider');
    if (qualitySlider) {
        qualitySlider.addEventListener('input', function() {
            GeneratorState.currentSettings.quality = parseInt(this.value);
            updateQualityDisplay();
            saveGeneratorPreferences();
        });
    }
}

function selectRatio(ratio) {
    // Update button states
    document.querySelectorAll('.ratio-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    const selectedBtn = document.querySelector(`[data-ratio="${ratio}"]`);
    if (selectedBtn) {
        selectedBtn.classList.add('active');
        GeneratorState.currentSettings.ratio = ratio;
        updateRatioPreview();
        saveGeneratorPreferences();
    }
}

function updateStylePreview() {
    const style = GeneratorState.currentSettings.style;
    console.log(`🎨 Estilo selecionado: ${style}`);
    
    // Update UI to reflect style choice
    const resultArea = document.getElementById('resultArea');
    if (resultArea && !GeneratorState.isGenerating) {
        const placeholder = resultArea.querySelector('.result-placeholder');
        if (placeholder) {
            const description = getStyleDescription(style);
            placeholder.querySelector('p').textContent = `Estilo ${style} selecionado. ${description}`;
        }
    }
}

function updateRatioPreview() {
    const ratio = GeneratorState.currentSettings.ratio;
    console.log(`📐 Proporção selecionada: ${ratio}`);
    
    // Update result area aspect ratio
    const resultArea = document.getElementById('resultArea');
    if (resultArea) {
        const aspectRatios = {
            '1:1': '1 / 1',
            '16:9': '16 / 9',
            '9:16': '9 / 16',
            '4:3': '4 / 3'
        };
        
        resultArea.style.aspectRatio = aspectRatios[ratio] || '1 / 1';
    }
}

function updateQualityDisplay() {
    const quality = GeneratorState.currentSettings.quality;
    const qualityLabels = ['Rascunho', 'Baixa', 'Média', 'Alta', 'Ultra HD'];
    const label = qualityLabels[quality - 1] || 'Média';
    
    console.log(`⚡ Qualidade selecionada: ${label} (${quality})`);
}

function getStyleDescription(style) {
    const descriptions = {
        'professional': 'Ideal para fotos corporativas e apresentações.',
        'creative': 'Perfeito para projetos artísticos e criativos.',
        'corporate': 'Adequado para materiais institucionais.',
        'lifestyle': 'Ótimo para conteúdo de estilo de vida.',
        'product': 'Especializado em fotografia de produtos.'
    };
    
    return descriptions[style] || 'Estilo versátil para diversos usos.';
}

// ===== PROMPT HANDLING =====
function setupPromptHandling() {
    const promptInput = document.getElementById('promptInput');
    if (promptInput) {
        // Real-time character counting
        promptInput.addEventListener('input', updatePromptCounter);
        
        // Auto-save draft
        promptInput.addEventListener('input', debounce(saveDraftPrompt, 1000));
        
        // Keyboard shortcuts
        promptInput.addEventListener('keydown', handlePromptKeyboard);
        
        // Load saved draft
        loadDraftPrompt();
    }
    
    // Random prompt button
    const randomizeBtn = document.getElementById('randomizeBtn');
    if (randomizeBtn) {
        randomizeBtn.addEventListener('click', generateRandomPrompt);
    }
}

function updatePromptCounter() {
    const promptInput = document.getElementById('promptInput');
    const promptCounter = document.getElementById('promptCounter');
    
    if (promptInput && promptCounter) {
        const length = promptInput.value.length;
        promptCounter.textContent = length;
        
        // Color coding based on length
        promptCounter.className = 'prompt-counter';
        if (length > 450) {
            promptCounter.classList.add('counter-danger');
        } else if (length > 350) {
            promptCounter.classList.add('counter-warning');
        } else if (length > 0) {
            promptCounter.classList.add('counter-good');
        }
    }
}

function saveDraftPrompt() {
    const promptInput = document.getElementById('promptInput');
    if (promptInput && promptInput.value.trim()) {
        localStorage.setItem('veo3-draft-prompt', promptInput.value);
    }
}

function loadDraftPrompt() {
    const draft = localStorage.getItem('veo3-draft-prompt');
    const promptInput = document.getElementById('promptInput');
    
    if (draft && promptInput && !promptInput.value) {
        promptInput.value = draft;
        updatePromptCounter();
    }
}

function handlePromptKeyboard(event) {
    // Ctrl/Cmd + Enter to generate
    if ((event.ctrlKey || event.metaKey) && event.key === 'Enter') {
        event.preventDefault();
        generateImage();
    }
    
    // Escape to clear
    if (event.key === 'Escape') {
        event.target.value = '';
        updatePromptCounter();
    }
}

function generateRandomPrompt() {
    const randomPrompts = [
        'Uma executiva confiante apresentando em uma sala de reuniões moderna, iluminação natural, fotografia profissional',
        'Produto tecnológico elegante em fundo minimalista branco, fotografia comercial de alta qualidade',
        'Equipe diversa colaborando em um escritório criativo, ambiente dinâmico e inspirador',
        'Paisagem urbana futurista ao entardecer, arquitetura contemporânea, cores vibrantes',
        'Chef profissional preparando prato gourmet em cozinha moderna, iluminação dramática',
        'Startup jovem em espaço de coworking, energia criativa, tecnologia e inovação',
        'Modelo de moda em estúdio minimalista, iluminação suave, estética contemporânea',
        'Arquiteto revisando projetos em escritório moderno, plantas e maquetes, luz natural'
    ];
    
    const randomPrompt = randomPrompts[Math.floor(Math.random() * randomPrompts.length)];
    const promptInput = document.getElementById('promptInput');
    
    if (promptInput) {
        // Animate text change
        promptInput.style.opacity = '0.5';
        setTimeout(() => {
            promptInput.value = randomPrompt;
            updatePromptCounter();
            promptInput.style.opacity = '1';
        }, 150);
        
        VEO3.showNotification('Prompt aleatório gerado!', 'success', 2000);
    }
}

// ===== GENERATION ACTIONS =====
function setupGenerationActions() {
    const generateBtn = document.getElementById('generateBtn');
    if (generateBtn) {
        generateBtn.addEventListener('click', generateImage);
    }
}

async function generateImage() {
    const promptInput = document.getElementById('promptInput');
    const prompt = promptInput?.value.trim();
    
    if (!prompt) {
        VEO3.showNotification('Por favor, digite um prompt para gerar a imagem', 'warning');
        promptInput?.focus();
        return;
    }
    
    if (prompt.length < 10) {
        VEO3.showNotification('O prompt deve ter pelo menos 10 caracteres', 'warning');
        return;
    }
    
    if (GeneratorState.isGenerating) {
        VEO3.showNotification('Aguarde a geração atual terminar', 'info');
        return;
    }
    
    console.log('🚀 Iniciando geração de imagem...');
    console.log('📝 Prompt:', prompt);
    console.log('⚙️ Configurações:', GeneratorState.currentSettings);
    
    try {
        GeneratorState.isGenerating = true;
        updateGenerationUI(true);
        
        // Simulate API call to VEO3
        const result = await simulateVEO3Generation(prompt, GeneratorState.currentSettings);
        
        // Display result
        displayGenerationResult(result);
        
        // Save to history
        saveToHistory(result);
        
        // Clear draft
        localStorage.removeItem('veo3-draft-prompt');
        
        VEO3.showNotification('Imagem gerada com sucesso!', 'success');
        
    } catch (error) {
        console.error('❌ Erro na geração:', error);
        VEO3.showNotification('Erro ao gerar imagem. Tente novamente.', 'error');
        displayGenerationError(error);
    } finally {
        GeneratorState.isGenerating = false;
        updateGenerationUI(false);
    }
}

function updateGenerationUI(isGenerating) {
    const generateBtn = document.getElementById('generateBtn');
    const resultArea = document.getElementById('resultArea');
    
    if (generateBtn) {
        if (isGenerating) {
            generateBtn.innerHTML = `
                <div class="loading-spinner"></div>
                Gerando...
            `;
            generateBtn.disabled = true;
        } else {
            generateBtn.innerHTML = `
                <i data-lucide="image"></i>
                Gerar Foto
            `;
            generateBtn.disabled = false;
        }
    }
    
    if (resultArea && isGenerating) {
        resultArea.innerHTML = `
            <div class="generation-progress">
                <div class="progress-circle">
                    <div class="progress-ring"></div>
                    <div class="progress-text">
                        <i data-lucide="zap"></i>
                        <span>Gerando com VEO3...</span>
                    </div>
                </div>
                <div class="progress-steps">
                    <div class="step active">Processando prompt</div>
                    <div class="step">Gerando imagem</div>
                    <div class="step">Finalizando</div>
                </div>
            </div>
        `;
    }
    
    // Re-initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

async function simulateVEO3Generation(prompt, settings) {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 3000 + Math.random() * 2000));
    
    // Simulate different outcomes
    const success = Math.random() > 0.1; // 90% success rate
    
    if (!success) {
        throw new Error('Falha na geração da imagem');
    }
    
    // Generate mock result
    const dimensions = getDimensionsFromRatio(settings.ratio);
    const imageUrl = generatePlaceholderImage(prompt, dimensions, settings.style);
    
    return {
        id: Date.now(),
        prompt: prompt,
        settings: { ...settings },
        imageUrl: imageUrl,
        dimensions: dimensions,
        generatedAt: new Date().toISOString(),
        processingTime: (3 + Math.random() * 2).toFixed(2) + 's',
        fileSize: (Math.random() * 5 + 1).toFixed(2) + ' MB'
    };
}

function getDimensionsFromRatio(ratio) {
    const ratioMap = {
        '1:1': { width: 1024, height: 1024 },
        '16:9': { width: 1920, height: 1080 },
        '9:16': { width: 1080, height: 1920 },
        '4:3': { width: 1600, height: 1200 }
    };
    
    return ratioMap[ratio] || ratioMap['1:1'];
}

function generatePlaceholderImage(prompt, dimensions, style) {
    const colors = {
        'professional': '2563EB',
        'creative': '7C3AED',
        'corporate': '059669',
        'lifestyle': 'F59E0B',
        'product': 'EF4444'
    };
    
    const color = colors[style] || '2563EB';
    const text = encodeURIComponent(prompt.substring(0, 30) + '...');
    
    return `https://via.placeholder.com/${dimensions.width}x${dimensions.height}/${color}/FFFFFF?text=${text}`;
}

function displayGenerationResult(result) {
    const resultArea = document.getElementById('resultArea');
    if (!resultArea) return;
    
    resultArea.innerHTML = `
        <div class="generation-result">
            <div class="result-image-container">
                <img src="${result.imageUrl}" alt="Imagem gerada" class="result-image" loading="lazy">
                <div class="result-overlay">
                    <div class="result-actions">
                        <button class="btn btn-primary" onclick="downloadImage('${result.imageUrl}', '${result.id}')">
                            <i data-lucide="download"></i>
                            Download
                        </button>
                        <button class="btn btn-outline" onclick="shareImage('${result.id}')">
                            <i data-lucide="share-2"></i>
                            Compartilhar
                        </button>
                        <button class="btn btn-outline" onclick="editImage('${result.id}')">
                            <i data-lucide="edit"></i>
                            Editar
                        </button>
                    </div>
                </div>
            </div>
            <div class="result-metadata">
                <div class="metadata-grid">
                    <div class="metadata-item">
                        <span class="metadata-label">Dimensões</span>
                        <span class="metadata-value">${result.dimensions.width}x${result.dimensions.height}</span>
                    </div>
                    <div class="metadata-item">
                        <span class="metadata-label">Tempo</span>
                        <span class="metadata-value">${result.processingTime}</span>
                    </div>
                    <div class="metadata-item">
                        <span class="metadata-label">Tamanho</span>
                        <span class="metadata-value">${result.fileSize}</span>
                    </div>
                    <div class="metadata-item">
                        <span class="metadata-label">Estilo</span>
                        <span class="metadata-value">${result.settings.style}</span>
                    </div>
                </div>
                <div class="result-prompt">
                    <span class="prompt-label">Prompt usado:</span>
                    <p class="prompt-text">"${result.prompt}"</p>
                </div>
            </div>
        </div>
    `;
    
    // Re-initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
    
    // Store current result
    GeneratorState.lastGeneration = result;
}

function displayGenerationError(error) {
    const resultArea = document.getElementById('resultArea');
    if (!resultArea) return;
    
    resultArea.innerHTML = `
        <div class="generation-error">
            <div class="error-icon">
                <i data-lucide="alert-circle"></i>
            </div>
            <h3 class="error-title">Erro na Geração</h3>
            <p class="error-message">${error.message}</p>
            <div class="error-actions">
                <button class="btn btn-primary" onclick="generateImage()">
                    <i data-lucide="refresh-cw"></i>
                    Tentar Novamente
                </button>
                <button class="btn btn-outline" onclick="contactSupport()">
                    <i data-lucide="help-circle"></i>
                    Suporte
                </button>
            </div>
        </div>
    `;
    
    // Re-initialize Lucide icons
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }
}

// ===== RESULT ACTIONS =====
function downloadImage(imageUrl, imageId) {
    const link = document.createElement('a');
    link.href = imageUrl;
    link.download = `veo3-image-${imageId}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    VEO3.showNotification('Download iniciado!', 'success', 2000);
}

function shareImage(imageId) {
    if (navigator.share) {
        navigator.share({
            title: 'Imagem gerada com VEO3',
            text: 'Confira esta imagem que criei com VEO3 Photo Generator!',
            url: window.location.href
        });
    } else {
        // Fallback: copy link to clipboard
        navigator.clipboard.writeText(window.location.href);
        VEO3.showNotification('Link copiado para a área de transferência!', 'success');
    }
}

function editImage(imageId) {
    VEO3.showNotification('Editor de imagens em breve!', 'info');
}

function contactSupport() {
    VEO3.showNotification('Redirecionando para o suporte...', 'info');
    // In real app, would open support chat or email
}

// ===== HISTORY MANAGEMENT =====
function saveToHistory(result) {
    if (!VEO3.AppState.generationHistory) {
        VEO3.AppState.generationHistory = [];
    }
    
    VEO3.AppState.generationHistory.unshift(result);
    
    // Keep only last 50 generations
    if (VEO3.AppState.generationHistory.length > 50) {
        VEO3.AppState.generationHistory = VEO3.AppState.generationHistory.slice(0, 50);
    }
    
    // Save to localStorage
    localStorage.setItem('veo3-generation-history', JSON.stringify(VEO3.AppState.generationHistory));
}

function loadGenerationHistory() {
    const saved = localStorage.getItem('veo3-generation-history');
    if (saved) {
        try {
            VEO3.AppState.generationHistory = JSON.parse(saved);
        } catch (error) {
            console.warn('Erro ao carregar histórico:', error);
            VEO3.AppState.generationHistory = [];
        }
    }
}

// ===== PREFERENCES =====
function saveGeneratorPreferences() {
    const preferences = {
        settings: GeneratorState.currentSettings,
        lastUsed: new Date().toISOString()
    };
    
    localStorage.setItem('veo3-generator-preferences', JSON.stringify(preferences));
}

function loadGeneratorPreferences() {
    const saved = localStorage.getItem('veo3-generator-preferences');
    if (saved) {
        try {
            const preferences = JSON.parse(saved);
            GeneratorState.currentSettings = { ...GeneratorState.currentSettings, ...preferences.settings };
            
            // Apply loaded settings to UI
            applySettingsToUI();
        } catch (error) {
            console.warn('Erro ao carregar preferências do gerador:', error);
        }
    }
    
    // Load generation history
    loadGenerationHistory();
}

function applySettingsToUI() {
    const { style, ratio, quality } = GeneratorState.currentSettings;
    
    // Apply style
    const styleSelect = document.getElementById('styleSelect');
    if (styleSelect) {
        styleSelect.value = style;
    }
    
    // Apply ratio
    selectRatio(ratio);
    
    // Apply quality
    const qualitySlider = document.getElementById('qualitySlider');
    if (qualitySlider) {
        qualitySlider.value = quality;
        updateQualityDisplay();
    }
}

// ===== UTILITY FUNCTIONS =====
function debounce(func, wait) {
    let timeout;
    return function executedFunction(...args) {
        const later = () => {
            clearTimeout(timeout);
            func(...args);
        };
        clearTimeout(timeout);
        timeout = setTimeout(later, wait);
    };
}

// ===== CSS INJECTION FOR GENERATOR STYLES =====
function injectGeneratorStyles() {
    const styles = `
        .loading-spinner {
            width: 16px;
            height: 16px;
            border: 2px solid transparent;
            border-top: 2px solid currentColor;
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            0% { transform: rotate(0deg); }
            100% { transform: rotate(360deg); }
        }
        
        .generation-progress {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: var(--space-xl);
            padding: var(--space-2xl);
        }
        
        .progress-circle {
            position: relative;
            width: 120px;
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .progress-ring {
            position: absolute;
            width: 100%;
            height: 100%;
            border: 3px solid var(--border-primary);
            border-top: 3px solid var(--primary);
            border-radius: 50%;
            animation: spin 2s linear infinite;
        }
        
        .progress-text {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: var(--space-sm);
            color: var(--text-secondary);
            font-size: 0.875rem;
        }
        
        .progress-steps {
            display: flex;
            flex-direction: column;
            gap: var(--space-sm);
            text-align: center;
        }
        
        .step {
            color: var(--text-muted);
            font-size: 0.875rem;
            transition: color var(--transition-fast);
        }
        
        .step.active {
            color: var(--primary);
            font-weight: 500;
        }
        
        .generation-result {
            display: flex;
            flex-direction: column;
            gap: var(--space-lg);
        }
        
        .result-image-container {
            position: relative;
            border-radius: var(--radius-lg);
            overflow: hidden;
            background: var(--bg-tertiary);
        }
        
        .result-image {
            width: 100%;
            height: auto;
            display: block;
        }
        
        .result-overlay {
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(0, 0, 0, 0.7);
            display: flex;
            align-items: center;
            justify-content: center;
            opacity: 0;
            transition: opacity var(--transition-normal);
        }
        
        .result-image-container:hover .result-overlay {
            opacity: 1;
        }
        
        .result-actions {
            display: flex;
            gap: var(--space-md);
        }
        
        .result-metadata {
            background: var(--bg-tertiary);
            border-radius: var(--radius-lg);
            padding: var(--space-lg);
        }
        
        .metadata-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
            gap: var(--space-lg);
            margin-bottom: var(--space-lg);
        }
        
        .metadata-item {
            text-align: center;
        }
        
        .metadata-label {
            display: block;
            font-size: 0.75rem;
            color: var(--text-muted);
            margin-bottom: var(--space-xs);
        }
        
        .metadata-value {
            display: block;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .result-prompt {
            border-top: 1px solid var(--border-primary);
            padding-top: var(--space-lg);
        }
        
        .prompt-label {
            font-size: 0.875rem;
            font-weight: 500;
            color: var(--text-secondary);
        }
        
        .prompt-text {
            margin-top: var(--space-sm);
            font-style: italic;
            color: var(--text-muted);
            line-height: 1.5;
        }
        
        .generation-error {
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: var(--space-lg);
            padding: var(--space-2xl);
            text-align: center;
        }
        
        .error-icon {
            width: 60px;
            height: 60px;
            background: var(--error);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
        }
        
        .error-icon i {
            font-size: 1.5rem;
        }
        
        .error-title {
            font-size: 1.25rem;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .error-message {
            color: var(--text-secondary);
            max-width: 400px;
        }
        
        .error-actions {
            display: flex;
            gap: var(--space-md);
        }
        
        .counter-danger {
            color: var(--error) !important;
        }
        
        .counter-warning {
            color: var(--warning) !important;
        }
        
        .counter-good {
            color: var(--success) !important;
        }
        
        @media (max-width: 768px) {
            .result-actions {
                flex-direction: column;
            }
            
            .metadata-grid {
                grid-template-columns: repeat(2, 1fr);
            }
            
            .error-actions {
                flex-direction: column;
                width: 100%;
            }
        }
    `;
    
    const styleSheet = document.createElement('style');
    styleSheet.textContent = styles;
    document.head.appendChild(styleSheet);
}

// Initialize styles when script loads
injectGeneratorStyles();

// ===== EXPORT =====
window.VEO3Generator = {
    GeneratorState,
    generateImage,
    generateRandomPrompt,
    downloadImage,
    shareImage,
    editImage
};

