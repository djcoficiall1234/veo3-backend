from flask import Blueprint, request, jsonify, session
from src.models.image_generation import db, ImageGeneration, UserSession
from src.services.veo3_service import VEO3Service, PromptOptimizer
from datetime import datetime
import uuid
import json

image_bp = Blueprint('image', __name__)
veo3_service = VEO3Service()

@image_bp.route('/generate', methods=['POST'])
def generate_image():
    """Generate image using VEO3 API"""
    try:
        data = request.get_json()
        
        # Validate required fields
        if not data or 'prompt' not in data:
            return jsonify({'error': 'Prompt é obrigatório'}), 400
        
        prompt = data['prompt'].strip()
        if len(prompt) < 10:
            return jsonify({'error': 'Prompt deve ter pelo menos 10 caracteres'}), 400
        
        # Extract parameters
        style = data.get('style', 'professional')
        aspect_ratio = data.get('aspect_ratio', '1:1')
        quality = data.get('quality', 4)
        category = data.get('category', 'general')
        
        # Get or create session
        session_id = session.get('session_id')
        if not session_id:
            session_id = str(uuid.uuid4())
            session['session_id'] = session_id
        
        # Optimize prompt
        optimized_prompt = PromptOptimizer.optimize_prompt(prompt, style, category)
        
        # Create generation record
        generation = ImageGeneration(
            prompt=optimized_prompt,
            style=style,
            aspect_ratio=aspect_ratio,
            quality=quality,
            category=category,
            session_id=session_id,
            status='processing'
        )
        
        db.session.add(generation)
        db.session.commit()
        
        # Generate image
        result = veo3_service.generate_image(
            prompt=optimized_prompt,
            style=style,
            aspect_ratio=aspect_ratio,
            quality=quality,
            session_id=session_id
        )
        
        if result.get('success'):
            # Update generation record with results
            generation.image_url = result['image_url']
            generation.thumbnail_url = result['thumbnail_url']
            generation.width = result['width']
            generation.height = result['height']
            generation.file_size = result['file_size']
            generation.processing_time = result['processing_time']
            generation.status = 'completed'
            
            db.session.commit()
            
            # Update session stats
            update_session_stats(session_id)
            
            return jsonify({
                'success': True,
                'generation_id': generation.id,
                'image_url': result['image_url'],
                'thumbnail_url': result['thumbnail_url'],
                'metadata': {
                    'width': result['width'],
                    'height': result['height'],
                    'file_size': result['file_size'],
                    'processing_time': f"{result['processing_time']:.2f}s",
                    'style': style,
                    'aspect_ratio': aspect_ratio,
                    'quality': quality
                },
                'prompt_used': optimized_prompt
            })
        else:
            # Update generation record with error
            generation.status = 'failed'
            generation.error_message = result.get('error', 'Erro desconhecido')
            db.session.commit()
            
            return jsonify({
                'success': False,
                'error': result.get('error', 'Falha na geração da imagem')
            }), 500
            
    except Exception as e:
        return jsonify({'error': f'Erro interno: {str(e)}'}), 500

@image_bp.route('/history', methods=['GET'])
def get_generation_history():
    """Get user's generation history"""
    try:
        session_id = session.get('session_id')
        if not session_id:
            return jsonify({'generations': []})
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 20, type=int)
        
        generations = ImageGeneration.query.filter_by(
            session_id=session_id,
            status='completed'
        ).order_by(ImageGeneration.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'generations': [gen.to_dict() for gen in generations.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': generations.total,
                'pages': generations.pages,
                'has_next': generations.has_next,
                'has_prev': generations.has_prev
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar histórico: {str(e)}'}), 500

@image_bp.route('/generation/<generation_id>', methods=['GET'])
def get_generation(generation_id):
    """Get specific generation details"""
    try:
        generation = ImageGeneration.query.get(generation_id)
        if not generation:
            return jsonify({'error': 'Geração não encontrada'}), 404
        
        # Increment view count
        generation.views += 1
        db.session.commit()
        
        return jsonify(generation.to_dict())
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar geração: {str(e)}'}), 500

@image_bp.route('/generation/<generation_id>/like', methods=['POST'])
def like_generation(generation_id):
    """Like a generation"""
    try:
        generation = ImageGeneration.query.get(generation_id)
        if not generation:
            return jsonify({'error': 'Geração não encontrada'}), 404
        
        generation.likes += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'likes': generation.likes
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao curtir: {str(e)}'}), 500

@image_bp.route('/generation/<generation_id>/download', methods=['POST'])
def download_generation(generation_id):
    """Track download of a generation"""
    try:
        generation = ImageGeneration.query.get(generation_id)
        if not generation:
            return jsonify({'error': 'Geração não encontrada'}), 404
        
        generation.downloads += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'downloads': generation.downloads
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao registrar download: {str(e)}'}), 500

@image_bp.route('/optimize-prompt', methods=['POST'])
def optimize_prompt():
    """Optimize a prompt for better results"""
    try:
        data = request.get_json()
        
        if not data or 'prompt' not in data:
            return jsonify({'error': 'Prompt é obrigatório'}), 400
        
        prompt = data['prompt'].strip()
        style = data.get('style', 'professional')
        category = data.get('category', 'general')
        
        optimized = PromptOptimizer.optimize_prompt(prompt, style, category)
        suggestions = PromptOptimizer.suggest_improvements(prompt)
        
        return jsonify({
            'original_prompt': prompt,
            'optimized_prompt': optimized,
            'suggestions': suggestions
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao otimizar prompt: {str(e)}'}), 500

@image_bp.route('/stats', methods=['GET'])
def get_stats():
    """Get generation statistics"""
    try:
        session_id = session.get('session_id')
        
        # Overall stats
        total_generations = ImageGeneration.query.filter_by(status='completed').count()
        
        # Session stats
        session_stats = {}
        if session_id:
            session_generations = ImageGeneration.query.filter_by(
                session_id=session_id,
                status='completed'
            ).count()
            session_stats = {
                'session_generations': session_generations
            }
        
        # Popular styles
        style_stats = db.session.query(
            ImageGeneration.style,
            db.func.count(ImageGeneration.id).label('count')
        ).filter_by(status='completed').group_by(ImageGeneration.style).all()
        
        return jsonify({
            'total_generations': total_generations,
            'session_stats': session_stats,
            'popular_styles': [{'style': style, 'count': count} for style, count in style_stats],
            'usage_stats': veo3_service.get_usage_stats(session_id)
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar estatísticas: {str(e)}'}), 500

def update_session_stats(session_id):
    """Update session statistics"""
    try:
        user_session = UserSession.query.get(session_id)
        if not user_session:
            user_session = UserSession(
                id=session_id,
                generation_count=1
            )
            db.session.add(user_session)
        else:
            user_session.generation_count += 1
            user_session.last_activity = datetime.utcnow()
        
        db.session.commit()
        
    except Exception as e:
        print(f"Erro ao atualizar estatísticas da sessão: {e}")

@image_bp.route('/session', methods=['GET'])
def get_session_info():
    """Get current session information"""
    try:
        session_id = session.get('session_id')
        if not session_id:
            session_id = str(uuid.uuid4())
            session['session_id'] = session_id
        
        user_session = UserSession.query.get(session_id)
        if not user_session:
            user_session = UserSession(id=session_id)
            db.session.add(user_session)
            db.session.commit()
        
        return jsonify({
            'session_id': session_id,
            'session_data': user_session.to_dict()
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar sessão: {str(e)}'}), 500

