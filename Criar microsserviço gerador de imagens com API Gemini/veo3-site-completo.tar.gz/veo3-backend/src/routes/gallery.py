from flask import Blueprint, request, jsonify
from src.models.image_generation import db, GalleryItem, ImageGeneration
from sqlalchemy import or_, and_
import json

gallery_bp = Blueprint('gallery', __name__)

@gallery_bp.route('/items', methods=['GET'])
def get_gallery_items():
    """Get gallery items with filtering and pagination"""
    try:
        # Query parameters
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        category = request.args.get('category', 'all')
        search = request.args.get('search', '')
        sort_by = request.args.get('sort_by', 'date')
        sort_order = request.args.get('sort_order', 'desc')
        featured_only = request.args.get('featured', False, type=bool)
        
        # Base query
        query = GalleryItem.query.filter_by(public=True)
        
        # Apply filters
        if category != 'all':
            query = query.filter_by(category=category)
        
        if featured_only:
            query = query.filter_by(featured=True)
        
        if search:
            search_term = f"%{search}%"
            query = query.filter(
                or_(
                    GalleryItem.title.ilike(search_term),
                    GalleryItem.description.ilike(search_term),
                    GalleryItem.tags.ilike(search_term),
                    GalleryItem.author.ilike(search_term)
                )
            )
        
        # Apply sorting
        if sort_by == 'date':
            order_col = GalleryItem.created_at
        elif sort_by == 'popularity':
            order_col = (GalleryItem.likes + GalleryItem.downloads)
        elif sort_by == 'views':
            order_col = GalleryItem.views
        elif sort_by == 'title':
            order_col = GalleryItem.title
        else:
            order_col = GalleryItem.created_at
        
        if sort_order == 'desc':
            query = query.order_by(order_col.desc())
        else:
            query = query.order_by(order_col.asc())
        
        # Paginate
        items = query.paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'items': [item.to_dict() for item in items.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': items.total,
                'pages': items.pages,
                'has_next': items.has_next,
                'has_prev': items.has_prev
            },
            'filters': {
                'category': category,
                'search': search,
                'sort_by': sort_by,
                'sort_order': sort_order,
                'featured_only': featured_only
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar itens da galeria: {str(e)}'}), 500

@gallery_bp.route('/item/<item_id>', methods=['GET'])
def get_gallery_item(item_id):
    """Get specific gallery item"""
    try:
        item = GalleryItem.query.get(item_id)
        if not item or not item.public:
            return jsonify({'error': 'Item não encontrado'}), 404
        
        # Increment view count
        item.views += 1
        db.session.commit()
        
        return jsonify(item.to_dict())
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar item: {str(e)}'}), 500

@gallery_bp.route('/item/<item_id>/like', methods=['POST'])
def like_gallery_item(item_id):
    """Like a gallery item"""
    try:
        item = GalleryItem.query.get(item_id)
        if not item:
            return jsonify({'error': 'Item não encontrado'}), 404
        
        item.likes += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'likes': item.likes
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao curtir item: {str(e)}'}), 500

@gallery_bp.route('/item/<item_id>/download', methods=['POST'])
def download_gallery_item(item_id):
    """Track download of a gallery item"""
    try:
        item = GalleryItem.query.get(item_id)
        if not item:
            return jsonify({'error': 'Item não encontrado'}), 404
        
        item.downloads += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'downloads': item.downloads
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao registrar download: {str(e)}'}), 500

@gallery_bp.route('/item/<item_id>/share', methods=['POST'])
def share_gallery_item(item_id):
    """Track share of a gallery item"""
    try:
        item = GalleryItem.query.get(item_id)
        if not item:
            return jsonify({'error': 'Item não encontrado'}), 404
        
        item.shares += 1
        db.session.commit()
        
        return jsonify({
            'success': True,
            'shares': item.shares
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao registrar compartilhamento: {str(e)}'}), 500

@gallery_bp.route('/categories', methods=['GET'])
def get_categories():
    """Get available categories"""
    try:
        categories = db.session.query(
            GalleryItem.category,
            db.func.count(GalleryItem.id).label('count')
        ).filter_by(public=True).group_by(GalleryItem.category).all()
        
        category_list = []
        for category, count in categories:
            category_list.append({
                'id': category,
                'name': get_category_name(category),
                'count': count
            })
        
        return jsonify({
            'categories': category_list
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar categorias: {str(e)}'}), 500

@gallery_bp.route('/featured', methods=['GET'])
def get_featured_items():
    """Get featured gallery items"""
    try:
        limit = request.args.get('limit', 6, type=int)
        
        items = GalleryItem.query.filter_by(
            featured=True,
            public=True
        ).order_by(GalleryItem.created_at.desc()).limit(limit).all()
        
        return jsonify({
            'featured_items': [item.to_dict() for item in items]
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar itens em destaque: {str(e)}'}), 500

@gallery_bp.route('/stats', methods=['GET'])
def get_gallery_stats():
    """Get gallery statistics"""
    try:
        total_items = GalleryItem.query.filter_by(public=True).count()
        total_views = db.session.query(db.func.sum(GalleryItem.views)).scalar() or 0
        total_likes = db.session.query(db.func.sum(GalleryItem.likes)).scalar() or 0
        total_downloads = db.session.query(db.func.sum(GalleryItem.downloads)).scalar() or 0
        
        # Popular categories
        popular_categories = db.session.query(
            GalleryItem.category,
            db.func.count(GalleryItem.id).label('count')
        ).filter_by(public=True).group_by(GalleryItem.category).order_by(
            db.func.count(GalleryItem.id).desc()
        ).limit(5).all()
        
        # Top items by likes
        top_items = GalleryItem.query.filter_by(public=True).order_by(
            GalleryItem.likes.desc()
        ).limit(5).all()
        
        return jsonify({
            'total_items': total_items,
            'total_views': total_views,
            'total_likes': total_likes,
            'total_downloads': total_downloads,
            'popular_categories': [
                {'category': cat, 'count': count} 
                for cat, count in popular_categories
            ],
            'top_items': [
                {
                    'id': item.id,
                    'title': item.title,
                    'likes': item.likes,
                    'thumbnail_url': item.thumbnail_url
                }
                for item in top_items
            ]
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro ao buscar estatísticas: {str(e)}'}), 500

@gallery_bp.route('/search', methods=['GET'])
def search_gallery():
    """Advanced search in gallery"""
    try:
        query_text = request.args.get('q', '')
        category = request.args.get('category')
        style = request.args.get('style')
        author = request.args.get('author')
        tags = request.args.get('tags', '').split(',') if request.args.get('tags') else []
        
        page = request.args.get('page', 1, type=int)
        per_page = request.args.get('per_page', 12, type=int)
        
        # Build query
        query = GalleryItem.query.filter_by(public=True)
        
        if query_text:
            search_term = f"%{query_text}%"
            query = query.filter(
                or_(
                    GalleryItem.title.ilike(search_term),
                    GalleryItem.description.ilike(search_term),
                    GalleryItem.prompt_used.ilike(search_term)
                )
            )
        
        if category:
            query = query.filter_by(category=category)
        
        if style:
            query = query.filter_by(style_used=style)
        
        if author:
            query = query.filter(GalleryItem.author.ilike(f"%{author}%"))
        
        if tags:
            for tag in tags:
                if tag.strip():
                    query = query.filter(GalleryItem.tags.ilike(f"%{tag.strip()}%"))
        
        # Paginate results
        results = query.order_by(GalleryItem.created_at.desc()).paginate(
            page=page, per_page=per_page, error_out=False
        )
        
        return jsonify({
            'results': [item.to_dict() for item in results.items],
            'pagination': {
                'page': page,
                'per_page': per_page,
                'total': results.total,
                'pages': results.pages,
                'has_next': results.has_next,
                'has_prev': results.has_prev
            },
            'search_params': {
                'query': query_text,
                'category': category,
                'style': style,
                'author': author,
                'tags': tags
            }
        })
        
    except Exception as e:
        return jsonify({'error': f'Erro na busca: {str(e)}'}), 500

def get_category_name(category):
    """Get display name for category"""
    category_names = {
        'business': 'Negócios',
        'product': 'Produtos',
        'people': 'Pessoas',
        'lifestyle': 'Lifestyle',
        'nature': 'Natureza',
        'technology': 'Tecnologia',
        'food': 'Alimentação',
        'travel': 'Viagem',
        'fashion': 'Moda',
        'art': 'Arte'
    }
    return category_names.get(category, category.title())

# Initialize sample gallery data
def init_sample_gallery_data():
    """Initialize sample gallery data if empty"""
    try:
        if GalleryItem.query.count() == 0:
            sample_items = [
                {
                    'title': 'Executiva Confiante',
                    'description': 'Retrato profissional de executiva em ambiente corporativo moderno',
                    'image_url': 'https://via.placeholder.com/800x600/2563EB/FFFFFF?text=Executiva+Confiante',
                    'thumbnail_url': 'https://via.placeholder.com/400x300/2563EB/FFFFFF?text=Executiva',
                    'width': 800,
                    'height': 600,
                    'file_size': '2.4 MB',
                    'category': 'business',
                    'tags': '["executiva", "profissional", "corporativo", "negócios"]',
                    'author': 'Maria Silva',
                    'prompt_used': 'Uma executiva confiante em um escritório moderno, luz natural, fotografia profissional',
                    'style_used': 'professional',
                    'views': 1250,
                    'likes': 142,
                    'downloads': 89,
                    'featured': True
                },
                {
                    'title': 'Produto Tecnológico',
                    'description': 'Fotografia comercial de produto tecnológico em fundo minimalista',
                    'image_url': 'https://via.placeholder.com/800x600/7C3AED/FFFFFF?text=Produto+Tech',
                    'thumbnail_url': 'https://via.placeholder.com/400x300/7C3AED/FFFFFF?text=Produto',
                    'width': 800,
                    'height': 600,
                    'file_size': '1.8 MB',
                    'category': 'product',
                    'tags': '["produto", "tecnologia", "minimalista", "comercial"]',
                    'author': 'João Santos',
                    'prompt_used': 'Produto tecnológico elegante em fundo minimalista branco, fotografia comercial',
                    'style_used': 'product',
                    'views': 890,
                    'likes': 98,
                    'downloads': 156,
                    'featured': False
                },
                {
                    'title': 'Equipe Colaborativa',
                    'description': 'Equipe diversa trabalhando em ambiente criativo e moderno',
                    'image_url': 'https://via.placeholder.com/800x600/10B981/FFFFFF?text=Equipe+Colaborativa',
                    'thumbnail_url': 'https://via.placeholder.com/400x300/10B981/FFFFFF?text=Equipe',
                    'width': 800,
                    'height': 600,
                    'file_size': '3.1 MB',
                    'category': 'people',
                    'tags': '["equipe", "colaboração", "diversidade", "trabalho"]',
                    'author': 'Ana Costa',
                    'prompt_used': 'Equipe diversa colaborando em escritório moderno, ambiente dinâmico',
                    'style_used': 'creative',
                    'views': 1580,
                    'likes': 203,
                    'downloads': 67,
                    'featured': True
                }
            ]
            
            for item_data in sample_items:
                item = GalleryItem(**item_data)
                db.session.add(item)
            
            db.session.commit()
            print("✅ Dados de exemplo da galeria inicializados")
            
    except Exception as e:
        print(f"❌ Erro ao inicializar dados da galeria: {e}")
        db.session.rollback()

