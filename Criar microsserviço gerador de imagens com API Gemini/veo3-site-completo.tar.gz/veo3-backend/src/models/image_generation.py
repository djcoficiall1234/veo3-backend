from src.models.user import db
from datetime import datetime
import uuid

class ImageGeneration(db.Model):
    __tablename__ = 'image_generations'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    prompt = db.Column(db.Text, nullable=False)
    style = db.Column(db.String(50), nullable=False, default='professional')
    aspect_ratio = db.Column(db.String(10), nullable=False, default='1:1')
    quality = db.Column(db.Integer, nullable=False, default=4)
    
    # Image metadata
    image_url = db.Column(db.String(500))
    thumbnail_url = db.Column(db.String(500))
    width = db.Column(db.Integer)
    height = db.Column(db.Integer)
    file_size = db.Column(db.String(20))
    
    # Generation metadata
    processing_time = db.Column(db.Float)
    status = db.Column(db.String(20), default='pending')  # pending, processing, completed, failed
    error_message = db.Column(db.Text)
    
    # User interaction
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'))
    session_id = db.Column(db.String(100))
    likes = db.Column(db.Integer, default=0)
    downloads = db.Column(db.Integer, default=0)
    views = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Categorization
    category = db.Column(db.String(50), default='general')
    tags = db.Column(db.Text)  # JSON string of tags
    featured = db.Column(db.Boolean, default=False)
    public = db.Column(db.Boolean, default=True)
    
    def to_dict(self):
        return {
            'id': self.id,
            'prompt': self.prompt,
            'style': self.style,
            'aspect_ratio': self.aspect_ratio,
            'quality': self.quality,
            'image_url': self.image_url,
            'thumbnail_url': self.thumbnail_url,
            'width': self.width,
            'height': self.height,
            'file_size': self.file_size,
            'processing_time': self.processing_time,
            'status': self.status,
            'error_message': self.error_message,
            'user_id': self.user_id,
            'session_id': self.session_id,
            'likes': self.likes,
            'downloads': self.downloads,
            'views': self.views,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'category': self.category,
            'tags': self.tags,
            'featured': self.featured,
            'public': self.public
        }

class PromptTemplate(db.Model):
    __tablename__ = 'prompt_templates'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = db.Column(db.String(200), nullable=False)
    prompt = db.Column(db.Text, nullable=False)
    description = db.Column(db.Text)
    category = db.Column(db.String(50), nullable=False)
    style = db.Column(db.String(50), nullable=False)
    
    # Usage statistics
    usage_count = db.Column(db.Integer, default=0)
    likes = db.Column(db.Integer, default=0)
    
    # Metadata
    created_by = db.Column(db.String(36), db.ForeignKey('users.id'))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Visibility
    public = db.Column(db.Boolean, default=True)
    featured = db.Column(db.Boolean, default=False)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'prompt': self.prompt,
            'description': self.description,
            'category': self.category,
            'style': self.style,
            'usage_count': self.usage_count,
            'likes': self.likes,
            'created_by': self.created_by,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None,
            'public': self.public,
            'featured': self.featured
        }

class UserSession(db.Model):
    __tablename__ = 'user_sessions'
    
    id = db.Column(db.String(100), primary_key=True)
    user_id = db.Column(db.String(36), db.ForeignKey('users.id'))
    
    # Session data
    theme_preference = db.Column(db.String(50), default='dark')
    custom_theme_data = db.Column(db.Text)  # JSON string
    generation_count = db.Column(db.Integer, default=0)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_activity = db.Column(db.DateTime, default=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'user_id': self.user_id,
            'theme_preference': self.theme_preference,
            'custom_theme_data': self.custom_theme_data,
            'generation_count': self.generation_count,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'last_activity': self.last_activity.isoformat() if self.last_activity else None
        }

class GalleryItem(db.Model):
    __tablename__ = 'gallery_items'
    
    id = db.Column(db.String(36), primary_key=True, default=lambda: str(uuid.uuid4()))
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    
    # Image data
    image_url = db.Column(db.String(500), nullable=False)
    thumbnail_url = db.Column(db.String(500))
    width = db.Column(db.Integer)
    height = db.Column(db.Integer)
    file_size = db.Column(db.String(20))
    
    # Metadata
    category = db.Column(db.String(50), nullable=False)
    tags = db.Column(db.Text)  # JSON string
    author = db.Column(db.String(100))
    prompt_used = db.Column(db.Text)
    style_used = db.Column(db.String(50))
    
    # Interaction stats
    views = db.Column(db.Integer, default=0)
    likes = db.Column(db.Integer, default=0)
    downloads = db.Column(db.Integer, default=0)
    shares = db.Column(db.Integer, default=0)
    
    # Visibility
    featured = db.Column(db.Boolean, default=False)
    public = db.Column(db.Boolean, default=True)
    
    # Timestamps
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    def to_dict(self):
        return {
            'id': self.id,
            'title': self.title,
            'description': self.description,
            'image_url': self.image_url,
            'thumbnail_url': self.thumbnail_url,
            'width': self.width,
            'height': self.height,
            'file_size': self.file_size,
            'category': self.category,
            'tags': self.tags,
            'author': self.author,
            'prompt_used': self.prompt_used,
            'style_used': self.style_used,
            'views': self.views,
            'likes': self.likes,
            'downloads': self.downloads,
            'shares': self.shares,
            'featured': self.featured,
            'public': self.public,
            'created_at': self.created_at.isoformat() if self.created_at else None,
            'updated_at': self.updated_at.isoformat() if self.updated_at else None
        }

