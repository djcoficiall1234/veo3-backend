import os
import sys
# DON'T CHANGE THIS !!!
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from flask import Flask, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Import models and routes
from src.models.user import db
from src.models.image_generation import ImageGeneration, PromptTemplate, UserSession, GalleryItem
from src.routes.user import user_bp
from src.routes.image_generation import image_bp
from src.routes.gallery import gallery_bp, init_sample_gallery_data
from src.routes.prompts import prompts_bp, init_sample_prompt_templates

app = Flask(__name__, static_folder=os.path.join(os.path.dirname(__file__), 'static'))

# Configuration
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'veo3_secret_key_2024')
app.config['SQLALCHEMY_DATABASE_URI'] = f"sqlite:///{os.path.join(os.path.dirname(__file__), 'database', 'app.db')}"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['MAX_CONTENT_LENGTH'] = int(os.getenv('MAX_CONTENT_LENGTH', 16777216))  # 16MB

# Enable CORS
CORS(app, origins=os.getenv('CORS_ORIGINS', '*').split(','))

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api/users')
app.register_blueprint(image_bp, url_prefix='/api/images')
app.register_blueprint(gallery_bp, url_prefix='/api/gallery')
app.register_blueprint(prompts_bp, url_prefix='/api/prompts')

# Initialize database
db.init_app(app)

# Create uploads directory
uploads_dir = os.path.join(os.path.dirname(__file__), 'static', 'uploads')
os.makedirs(uploads_dir, exist_ok=True)

# Serve uploaded files
@app.route('/uploads/<filename>')
def uploaded_file(filename):
    return send_from_directory(uploads_dir, filename)

# Health check endpoint
@app.route('/api/health')
def health_check():
    return {'status': 'healthy', 'service': 'VEO3 Photo Generator API'}

# Serve frontend
@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve(path):
    static_folder_path = app.static_folder
    if static_folder_path is None:
        return "Static folder not configured", 404

    if path != "" and os.path.exists(os.path.join(static_folder_path, path)):
        return send_from_directory(static_folder_path, path)
    else:
        index_path = os.path.join(static_folder_path, 'index.html')
        if os.path.exists(index_path):
            return send_from_directory(static_folder_path, 'index.html')
        else:
            return "index.html not found", 404

# Initialize database and sample data
with app.app_context():
    db.create_all()
    
    # Initialize sample data
    init_sample_gallery_data()
    init_sample_prompt_templates()
    
    print("✅ VEO3 Backend inicializado com sucesso!")
    print(f"📁 Diretório de uploads: {uploads_dir}")
    print(f"🗄️ Banco de dados: {app.config['SQLALCHEMY_DATABASE_URI']}")

if __name__ == '__main__':
    port = int(os.getenv('PORT', 5000))
    debug = os.getenv('FLASK_ENV') == 'development'
    
    print(f"🚀 Iniciando VEO3 Backend na porta {port}")
    print(f"🔧 Modo debug: {debug}")
    
    app.run(host='0.0.0.0', port=port, debug=debug)
